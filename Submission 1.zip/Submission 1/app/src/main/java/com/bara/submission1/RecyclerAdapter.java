package com.bara.submission1;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    public ArrayList<Data> mData;

    public RecyclerAdapter(ArrayList<Data> mData) {
        this.mData = mData;
    }

    @NonNull
    @Override
    public RecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.ViewHolder holder, int position) {
        final Data data = mData.get(position);
        Glide.with(holder.itemView.getContext())
                .load(data.getAvatar())
                .into(holder.avatarList);
        holder.nameList.setText(data.getName());
        holder.locList.setText(data.getLocation());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), Detail.class);
                i.putExtra("data", data);
                view.getContext().startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView avatarList;
        TextView nameList;
        TextView locList;
        LinearLayout linearLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            avatarList = itemView.findViewById(R.id.img_avatar_item);
            nameList = itemView.findViewById(R.id.txt_name_item);
            locList = itemView.findViewById(R.id.txt_location_item);
            linearLayout = itemView.findViewById(R.id.linear_layout_item);
        }
    }
}
