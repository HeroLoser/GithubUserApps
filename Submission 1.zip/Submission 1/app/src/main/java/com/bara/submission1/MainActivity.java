package com.bara.submission1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Data> mData = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        
        mData.add(new Data("Jake Wharton", "JakeWharton", "Google, Inc.", "Pittsburgh, PA, USA", "102", "56995", "12", R.drawable.user1));
        mData.add(new Data("Amit Shekhar", "amitshekhariitbhu", "MindOrksOpenSource", "New Delhi, India", "37", "5153", "2", R.drawable.user2));
        mData.add(new Data("Romain Guy", "romainguy", "Google", "California", "9", "7972", "0", R.drawable.user3));
        mData.add(new Data("Chris Banes", "chrisbanes", "Google working on @android", "Sydney, Australia", "30", "14729", "1", R.drawable.user4));
        mData.add(new Data("David", "tipsy", "Working Group Two", "Trondheim, Norway", "56", "788", "0", R.drawable.user5));
        mData.add(new Data("Ravi Tamada", "ravi8x", "AndroidHive | Droid5", "India", "28", "18628", "3", R.drawable.user6));
        mData.add(new Data("Deny Prasetyo", "jasoet", "gojek-engineering", "Kotagede, Yogyakarta, Indonesia", "44", "277", "39", R.drawable.user7));
        mData.add(new Data("Budi Oktaviyan", "budioktaviyan", "KotlinID", "Jakarta, Indonesia", "110", "178", "23", R.drawable.user8));
        mData.add(new Data("Hendi Santika", "hendisantika", "JVMDeveloperID @KotlinID @IDDevOps", "Bojongsoang - Bandung Jawa Bara", "1064", "428", "61", R.drawable.user9));
        mData.add(new Data("Sidiq Permana", "sidiqpermana", "Nusantara Beta Studio", "Jakarta Indonesia", "65", "465", "10", R.drawable.user10));

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        RecyclerAdapter adapter = new RecyclerAdapter(mData);
        recyclerView.setAdapter(adapter);
    }

}
