package com.bara.submission1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Detail extends AppCompatActivity {

    private TextView txtName, txtFollowers, txtFollowing, txtRepository;
    private ImageView imgAvatar;
    private EditText edtUsename, edtCompany, edtLocation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        txtName = findViewById(R.id.NamaDetail);
        txtFollowers = findViewById(R.id.countFollowers);
        txtFollowing = findViewById(R.id.countFollowing);
        txtRepository = findViewById(R.id.countRepo);
        edtCompany = findViewById(R.id.edt_company_detail);
        edtLocation = findViewById(R.id.edt_location_detail);
        edtUsename = findViewById(R.id.edt_username_detail);
        imgAvatar = findViewById(R.id.img_avatar_detail);

        Data data = getIntent().getParcelableExtra("data");
        if (data != null){
            txtName.setText(data.getName());
            txtRepository.setText(data.getRepository());
            txtFollowers.setText(data.getFollowers());
            txtFollowing.setText(data.getFollowing());
            edtUsename.setText(data.getUsername());
            edtCompany.setText(data.getCompany());
            edtLocation.setText(data.getLocation());
            imgAvatar.setImageResource(data.getAvatar());
        }

    }
}
